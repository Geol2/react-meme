package com.example.demo.exceptions;

public class MakeXlsxFileException extends RuntimeException {

	private static final long serialVersionUID = 6066793019005014634L;

	public MakeXlsxFileException(String message) {
		super(message);
	}
	
}
