package com.example.demo.member.vo.validategroup;

public interface MemberLoginGroup {

}
